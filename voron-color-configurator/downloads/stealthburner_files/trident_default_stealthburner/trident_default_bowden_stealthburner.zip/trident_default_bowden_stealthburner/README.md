# Filename Nomenclature

| Filename | Note |
|----------|------|
| \*.stl | Base color |
| [a]\_\*.stl | Accent colors |
| [o]\_\*.stl | Opaque filament (light doesn't penetrate) |
| [c]\_\*.stl | Clear/Translucent filament (light can penetrate) |
| \*\_cw1.stl | Clockwork1 Version |
| \*\_cw2.stl | Clockwork2 Version |
