
these Multibody STls are provided to make multi color printing of common parts such as the Cowling and skirts easier.

to use these STLs to print multi color parts import them into your slicer and split into parts (not objects) you can then use part specific settings to do things like color swaps or deleting top/bottom layer to make mesh skirts.
